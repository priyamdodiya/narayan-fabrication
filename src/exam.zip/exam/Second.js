import React from 'react'
import "./Second.css"
import P3 from "../assets/p3.png"
const Second = () => {
  return (
    <div className='second'>
        <div className='secondleft'>
        <img src={P3}/>
        </div>
        <div class="secondright">
            <h3>Latest post heading sample tex..</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
        </div>
    </div>
  )
}

export default Second
