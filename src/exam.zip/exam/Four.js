import React from 'react'
import "./For.css"
import P5 from "../assets/p5.png"
const Four = () => {
  return (
    <div className='four'>
      <div className='l' style={{paddingTop:"200px",paddingLeft:"200px"}}>
        <h3>Download</h3>
        <h1><b>Otarea Educore App</b></h1>
        <h3>For non stop learning</h3>
        <button style={{padding:"0 30px",backgroundColor:"green",border:"1px solid black", marginTop:"50px",borderRadius:"5px"}}>Download Now</button>
      </div>
      <div className='r'>
      <img src={P5}/>
      </div>
    </div>
  )
}

export default Four
