import React from 'react'
import "./Navbar.css"
import P1 from "../assets/p1.png"
const Navbar = () => {
  return (
    <div className='navbar'>
        <div className='logo'>
      <img src={P1}/>
      <h2>Otaria.in</h2>
      <p> | Blog</p>
      </div>
      <div className='leftside'>
        <ul>
            <li>Archives</li>
            <li>Store</li>
        </ul>
        <button>Get a Quate</button>
      </div>
    </div>
  )
}

export default Navbar
