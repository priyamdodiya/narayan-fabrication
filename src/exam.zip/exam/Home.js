import React from 'react'
import "./Home.css"
import P2 from "../assets/p2.png"
const Home = () => {
  return (
    <div className='home'>
        <div className='left'>
    <div className='leftbox'>
      <h2 style={{paddingBottom:"20px"}}>Let's Explore <br/> new Possiblities</h2>
      <input type='text' placeholder='How to etc...' />
      <ul style={{paddingTop:"20px"}}>
        <li># DESIGN</li>
        <li># DEVELOP</li>
        <li># MARKET</li>
      </ul>
      </div>
      </div>
      <div className='right'>
    <img src={P2}/>
      </div>
    </div>
  )
}
export default Home
