import React from 'react'
import "./Third.css"
import P4 from "../assets/p4.png"
const Third = () => {
  return (
    <div className='third'>
      <div className='card'>
        <img src={P4}/>
        <h3>Other post heading sample tex...</h3>
        <div style={{display:"flex",gap:"90px"}}>
           <p>By Writter Name</p>
           <p>23 Dec.</p>
        </div>
        <p style={{fontSize:"15px"}}>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
      </div>
      <div className='card'>
        <img src={P4}/>
        <h3>Other post heading sample tex...</h3>
        <div style={{display:"flex",gap:"90px"}}>
           <p>By Writter Name</p>
           <p>23 Dec.</p>
        </div>
        <p style={{fontSize:"15px"}}>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
      </div>
      <div className='card'>
        <img src={P4}/>
        <h3>Other post heading sample tex...</h3>
        <div style={{display:"flex",gap:"90px"}}>
           <p>By Writter Name</p>
           <p>23 Dec.</p>
        </div>
        <p style={{fontSize:"15px"}}>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.”</p>
      </div>
    </div>
  )
}

export default Third
